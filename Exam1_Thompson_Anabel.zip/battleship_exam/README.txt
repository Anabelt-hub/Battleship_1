Folder name for htdocs:
battleship_exam

Run URL:
http://localhost/battleship_exam/

New Feature 1 (Persistent):
Server-side JSON Scoreboard
- File: /battleship_exam/scoreboard.json
- Endpoint: /battleship_exam/score_api.php?action=get|recordWin|recordLoss|recordShot|reset
- Persists across refresh and Apache restart.

New Feature 2:
Undo Last Shot (one-step undo)
- Client-side snapshot using serializeGame()/deserializeGame()
- Works only before the CPU fires (cancels the scheduled CPU move).

LOOM video:
https://www.loom.com/share/9ea12f069d6d4ba2886395f8467c816c

